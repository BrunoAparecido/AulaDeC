#include<stdio.h>
#include<locale.h>

maximo(int a, int b){
	if (a > b){
		printf("O maior valor �: %d \n", a);
	} else {
		printf("O maior valor �: %d \n", b);
	}
}

main(){
	setlocale(LC_ALL, "Portuguese");
	int valora, valorb;
	
	printf("Digite o valor de a: ");
	scanf("%d", &valora);
	printf("Digite o valor de b: ");
	scanf("%d", &valorb);
	maximo(valora, valorb);
	
	system("pause");
}
	

