#include<stdio.h>
#include<locale.h>

quadrado(int lado1, int lado2){
	if (lado1 == lado2){
		printf("� um quadrado! \n");
	} else {
		printf("� um ret�ngulo! \n");
	}
}
main(){
	setlocale(LC_ALL, "Portuguese");
	int val1, val2;
	
	printf("Digite o valor de um dos lados: ");
	scanf("%d", &val1);
	printf("Digite o valor de outro lado: ");
	scanf("%d", &val2);
	quadrado(val1, val2);
	
	system("pause");
}
