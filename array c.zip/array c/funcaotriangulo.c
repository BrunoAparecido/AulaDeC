#include<stdio.h>
#include<locale.h>

triangulo(int val1, int val2, int val3){
	if ((val1 == val2) && (val2 == val3)){
		printf("Tri�ngulo equil�tero! \n");
	} else {
		if ((val1 == val2) || (val1 == val3) || (val2 == val3)){
			printf("Tri�ngulo is�sceles! \n");
		} else {
			printf("Tri�ngulo escaleno! \n");
		}
	}
}

main(){
	setlocale(LC_ALL, "Portuguese");
	int a, b, c;
	
	printf("Digite o valor de a: ");
	scanf("%d", &a);
	printf("Digite o valor de b: ");
	scanf("%d", &b);
	printf("Digite o valor de c: ");
	scanf("%d", &c);
	triangulo(a, b, c);
	
	system("pause");
}
